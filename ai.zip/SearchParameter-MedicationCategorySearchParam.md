# MedicationCategorySearchParam - Pharmac Schedules FHIR API v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MedicationCategorySearchParam**

## SearchParameter: MedicationCategorySearchParam 

| | |
| :--- | :--- |
| *Official URL*:https://fhir-ig.digital.health.nz/pharmac-schedules/SearchParameter/medication-category | *Version*:1.1.0 |
| Active as of 2026-06-24 | *Computable Name*:medication-category |

 
Search for medications by ATC category 



## Resource Content

```json
{
  "resourceType" : "SearchParameter",
  "id" : "MedicationCategorySearchParam",
  "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/SearchParameter/medication-category",
  "version" : "1.1.0",
  "name" : "medication-category",
  "status" : "active",
  "date" : "2026-06-24T20:43:54+00:00",
  "publisher" : "Pharmac",
  "contact" : [{
    "name" : "Pharmac",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.pharmac.govt.nz/about/contact"
    }]
  },
  {
    "name" : "Pharmac",
    "telecom" : [{
      "system" : "email",
      "value" : "enquiry@pharmac.govt.nz",
      "use" : "work"
    }]
  }],
  "description" : "Search for medications by ATC category",
  "code" : "category",
  "base" : ["Medication"],
  "type" : "string",
  "expression" : "Medication.extension.where(url='https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-atc').value.ofType(CodeableConcept).text",
  "xpathUsage" : "normal",
  "target" : ["Medication"]
}

```
