# Medication-Lucrin-Depot-1-Month - Pharmac Schedules FHIR API v0.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Medication-Lucrin-Depot-1-Month**

## Example Medication: Medication-Lucrin-Depot-1-Month



## Resource Content

```json
{
  "resourceType" : "Medication",
  "id" : "Medication-Lucrin-Depot-1-Month",
  "meta" : {
    "profile" : ["https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/pharmac-medication"]
  },
  "extension" : [{
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-brand-name",
    "valueString" : "Lucrin Depot 1-month"
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-package-size",
    "valueString" : "1"
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-unit-of-measure",
    "valueString" : "inj"
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-rank",
    "valueInteger" : 4
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-atc-category-1",
    "valueString" : "Hormone Preparations - Systemic Excluding Contraceptive Hormones"
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-atc-category-2",
    "valueString" : "Trophic Hormones"
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-atc-category-3",
    "valueString" : "GnRH Analogues"
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-product-multiple",
    "valueBoolean" : true
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-product-multiplier",
    "valueInteger" : 1
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-original-pack",
    "valueBoolean" : false
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-safety-list-medicine",
    "valueBoolean" : false
  }],
  "identifier" : [{
    "system" : "http://schedule.pharmac.govt.nz/ids/brand",
    "value" : "B14160310092925"
  },
  {
    "system" : "http://schedule.pharmac.govt.nz/ids/pack",
    "value" : "P2330148"
  },
  {
    "system" : "http://schedule.pharmac.govt.nz/ids/chemical",
    "value" : "C1416031009"
  },
  {
    "system" : "http://schedule.pharmac.govt.nz/ids/formulation",
    "value" : "F141603100929"
  },
  {
    "system" : "http://schedule.pharmac.govt.nz/ids/pharmacode",
    "value" : "2330148"
  }],
  "code" : {
    "coding" : [{
      "system" : "http://nzmt.org.nz",
      "code" : "50049431000117108",
      "display" : "Leuprorelin 3.75 inj, 1 inj"
    }],
    "text" : "Leuprorelin"
  },
  "status" : "active",
  "form" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "412946008",
      "display" : "Injectable solution"
    }],
    "text" : "Inj 3.75 mg prefilled dual chamber syringe"
  },
  "ingredient" : [{
    "itemCodeableConcept" : {
      "coding" : [{
        "system" : "http://nzmt.org.nz",
        "code" : "2268011000036106",
        "display" : "leuprorelin"
      }],
      "text" : "leuprorelin"
    },
    "isActive" : true
  }]
}

```
