# SearchSet-Bundle-All-Medications - Pharmac Schedules FHIR API v1.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **SearchSet-Bundle-All-Medications**

## Example Bundle: SearchSet-Bundle-All-Medications



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "SearchSet-Bundle-All-Medications",
  "type" : "searchset",
  "total" : 1000,
  "link" : [{
    "relation" : "self",
    "url" : "https://pharmacfhirpoc-api.fhir.azurehealthcareapis.com/Medication"
  },
  {
    "relation" : "next",
    "url" : "https://pharmacfhirpoc-api.fhir.azurehealthcareapis.com/Medication?_count=1000&ct=er97f5lRTbS5qY6poaGRqaWFoamliYWRkYmxiaVlLAAAAP%2F%2F"
  }],
  "entry" : [{
    "resource" : {
      "resourceType" : "Medication",
      "id" : "Medication-Clexane-100mg-1ml-Syringe",
      "meta" : {
        "profile" : ["https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/pharmac-medication"]
      },
      "extension" : [{
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-brand-name",
        "valueString" : "Clexane"
      },
      {
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-package-size",
        "valueString" : "10"
      },
      {
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-unit-of-measure",
        "valueString" : "syringe"
      },
      {
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-rank",
        "valueInteger" : 4
      },
      {
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-atc-category-1",
        "valueString" : "Blood and Blood Forming Organs"
      },
      {
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-atc-category-2",
        "valueString" : "Antithrombotic Agents"
      },
      {
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-atc-category-3",
        "valueString" : "Heparin and Antagonist Preparations"
      },
      {
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-product-multiple",
        "valueBoolean" : true
      },
      {
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-product-multiplier",
        "valueInteger" : 1
      },
      {
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-original-pack",
        "valueBoolean" : false
      },
      {
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-safety-list-medicine",
        "valueBoolean" : false
      },
      {
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-strength",
        "valueString" : "100 mg in 1 ml"
      },
      {
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-legal-classification",
        "valueString" : "Presciption"
      },
      {
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-product-created-date",
        "valueDate" : "2009-08-01"
      }],
      "identifier" : [{
        "system" : "http://schedule.pharmac.govt.nz/ids/brand",
        "value" : "B04070438932925"
      },
      {
        "system" : "http://schedule.pharmac.govt.nz/ids/pack",
        "value" : "P2581906"
      },
      {
        "system" : "http://schedule.pharmac.govt.nz/ids/chemical",
        "value" : "C0407043893"
      },
      {
        "system" : "http://schedule.pharmac.govt.nz/ids/formulation",
        "value" : "F040704389329"
      },
      {
        "system" : "http://schedule.pharmac.govt.nz/ids/pharmacode",
        "value" : "2581906"
      },
      {
        "system" : "https://www.gs1.org/gtin",
        "value" : "09312319039680"
      },
      {
        "system" : "https://www.gs1.org/gtin",
        "value" : "09319733003402"
      }],
      "code" : {
        "coding" : [{
          "system" : "http://nzmt.org.nz",
          "code" : "50083501000117108",
          "display" : "Inj 100 mg in 1 ml syringe"
        }],
        "text" : "Clexane"
      },
      "status" : "active",
      "form" : {
        "text" : "Solution for injection"
      },
      "ingredient" : [{
        "itemCodeableConcept" : {
          "text" : "Enoxaparin sodium"
        },
        "isActive" : true
      }]
    },
    "search" : {
      "mode" : "include"
    }
  },
  {
    "resource" : {
      "resourceType" : "Medication",
      "id" : "Medication-Fortisip-Multi-Fibre-Chocolate",
      "meta" : {
        "profile" : ["https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/pharmac-medication"]
      },
      "extension" : [{
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-brand-name",
        "valueString" : "Fortisip Multi Fibre (chocolate)"
      },
      {
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-package-size",
        "valueString" : "200"
      },
      {
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-unit-of-measure",
        "valueString" : "ml"
      },
      {
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-atc-category-1",
        "valueString" : "Special Foods"
      },
      {
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-atc-category-2",
        "valueString" : "Standard Feeds"
      },
      {
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-atc-category-3",
        "valueString" : "Standard Feeds"
      }],
      "identifier" : [{
        "system" : "http://schedule.pharmac.govt.nz/ids/brand",
        "value" : "B42063138522825"
      },
      {
        "system" : "http://schedule.pharmac.govt.nz/ids/pack",
        "value" : "P2702614"
      },
      {
        "system" : "http://schedule.pharmac.govt.nz/ids/chemical",
        "value" : "C4206313852"
      },
      {
        "system" : "http://schedule.pharmac.govt.nz/ids/formulation",
        "value" : "F420631385228"
      },
      {
        "system" : "http://schedule.pharmac.govt.nz/ids/pharmacode",
        "value" : "2702614"
      }],
      "code" : {
        "coding" : [{
          "system" : "http://nzmt.org.nz",
          "code" : "50035701000117108"
        }],
        "text" : "Fortisip Multi Fibre (chocolate)"
      },
      "status" : "active",
      "form" : {
        "text" : "Liquid"
      }
    },
    "search" : {
      "mode" : "include"
    }
  },
  {
    "resource" : {
      "resourceType" : "Medication",
      "id" : "Medication-Nutrison-800-Complete-Multi-Fibre",
      "meta" : {
        "profile" : ["https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/pharmac-medication"]
      },
      "extension" : [{
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-brand-name",
        "valueString" : "Nutrison 800 Complete Multi Fibre"
      },
      {
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-package-size",
        "valueString" : "1000"
      },
      {
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-unit-of-measure",
        "valueString" : "ml"
      },
      {
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-atc-category-1",
        "valueString" : "Special Foods"
      },
      {
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-atc-category-2",
        "valueString" : "Standard Feeds"
      },
      {
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-atc-category-3",
        "valueString" : "Standard Feeds"
      }],
      "identifier" : [{
        "system" : "http://schedule.pharmac.govt.nz/ids/brand",
        "value" : "B42063140742625"
      },
      {
        "system" : "http://schedule.pharmac.govt.nz/ids/pack",
        "value" : "P2702398"
      },
      {
        "system" : "http://schedule.pharmac.govt.nz/ids/chemical",
        "value" : "C4206314074"
      },
      {
        "system" : "http://schedule.pharmac.govt.nz/ids/formulation",
        "value" : "F420631407426"
      },
      {
        "system" : "http://schedule.pharmac.govt.nz/ids/pharmacode",
        "value" : "2702398"
      }],
      "code" : {
        "coding" : [{
          "system" : "http://nzmt.org.nz",
          "code" : "50271881000117104"
        }],
        "text" : "Nutrison 800 Complete Multi Fibre"
      },
      "status" : "active",
      "form" : {
        "text" : "Liquid"
      }
    },
    "search" : {
      "mode" : "include"
    }
  }]
}

```
