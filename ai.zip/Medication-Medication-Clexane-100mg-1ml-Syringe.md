# Medication-Clexane-100mg-1ml-Syringe - Pharmac Schedules FHIR API v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Medication-Clexane-100mg-1ml-Syringe**

## Example Medication: Medication-Clexane-100mg-1ml-Syringe



## Resource Content

```json
{
  "resourceType" : "Medication",
  "id" : "Medication-Clexane-100mg-1ml-Syringe",
  "meta" : {
    "profile" : ["https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/pharmac-medication"]
  },
  "extension" : [{
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-brand-name",
    "valueString" : "Clexane"
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-package-size",
    "valueString" : "10"
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-unit-of-measure",
    "valueString" : "syringe"
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-rank",
    "valueInteger" : 4
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-atc-category-1",
    "valueString" : "Blood and Blood Forming Organs"
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-atc-category-2",
    "valueString" : "Antithrombotic Agents"
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-atc-category-3",
    "valueString" : "Heparin and Antagonist Preparations"
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-product-multiple",
    "valueBoolean" : true
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-product-multiplier",
    "valueInteger" : 1
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-original-pack",
    "valueBoolean" : false
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-safety-list-medicine",
    "valueBoolean" : false
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-strength",
    "valueString" : "100 mg in 1 ml"
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-legal-classification",
    "valueString" : "Presciption"
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-product-created-date",
    "valueDate" : "2009-08-01"
  }],
  "identifier" : [{
    "system" : "http://schedule.pharmac.govt.nz/ids/brand",
    "value" : "B04070438932925"
  },
  {
    "system" : "http://schedule.pharmac.govt.nz/ids/pack",
    "value" : "P2581906"
  },
  {
    "system" : "http://schedule.pharmac.govt.nz/ids/chemical",
    "value" : "C0407043893"
  },
  {
    "system" : "http://schedule.pharmac.govt.nz/ids/formulation",
    "value" : "F040704389329"
  },
  {
    "system" : "http://schedule.pharmac.govt.nz/ids/pharmacode",
    "value" : "2581906"
  },
  {
    "system" : "https://www.gs1.org/gtin",
    "value" : "09312319039680"
  },
  {
    "system" : "https://www.gs1.org/gtin",
    "value" : "09319733003402"
  }],
  "code" : {
    "coding" : [{
      "system" : "http://nzmt.org.nz",
      "code" : "50083501000117108",
      "display" : "Inj 100 mg in 1 ml syringe"
    }],
    "text" : "Clexane"
  },
  "status" : "active",
  "form" : {
    "text" : "Solution for injection"
  },
  "ingredient" : [{
    "itemCodeableConcept" : {
      "text" : "Enoxaparin sodium"
    },
    "isActive" : true
  }]
}

```
