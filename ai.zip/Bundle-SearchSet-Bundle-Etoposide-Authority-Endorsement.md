# SearchSet-Bundle-Etoposide-Authority-Endorsement - Pharmac Schedules FHIR API v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **SearchSet-Bundle-Etoposide-Authority-Endorsement**

## Example Bundle: SearchSet-Bundle-Etoposide-Authority-Endorsement



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "SearchSet-Bundle-Etoposide-Authority-Endorsement",
  "type" : "searchset",
  "total" : 1,
  "link" : [{
    "relation" : "self",
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/Medication?code=50225401000117106&_revinclude=ChargeItemDefinition:instance"
  }],
  "entry" : [{
    "fullUrl" : "https://fhir-ig.digital.health.nz/pharmac-schedules/Medication/50225401000117106",
    "resource" : {
      "resourceType" : "Medication",
      "id" : "50225401000117106",
      "meta" : {
        "profile" : ["https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/pharmac-medication"]
      },
      "extension" : [{
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-nzmt-type",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://standards.digital.health.nz/ns/nzmt-type-code",
            "code" : "ctpp"
          }],
          "text" : "ctpp"
        }
      },
      {
        "extension" : [{
          "url" : "type",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://nzmt.org.nz",
              "code" : "20069071000116107",
              "display" : "Preferred Term"
            }],
            "text" : "Preferred Term"
          }
        },
        {
          "url" : "term",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://nzmt.org.nz",
              "code" : "50225401000117106",
              "display" : "Etoposide (Rex) 100 mg/5 mL injection: concentrated, 1 x 5 mL vial"
            }],
            "text" : "Etoposide (Rex) 100 mg/5 mL injection: concentrated, 1 x 5 mL vial"
          }
        }],
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-description"
      },
      {
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-atc",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.whocc.no/atc",
            "code" : "L01CB01",
            "display" : "etoposide"
          }],
          "text" : "etoposide"
        }
      },
      {
        "extension" : [{
          "url" : "quantity",
          "valueQuantity" : {
            "value" : 1,
            "unit" : "vial"
          }
        }],
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-pack"
      },
      {
        "extension" : [{
          "url" : "price",
          "valueMoney" : {
            "value" : 7.9,
            "currency" : "NZD"
          }
        }],
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-price"
      }],
      "code" : {
        "coding" : [{
          "system" : "http://nzmt.org.nz",
          "code" : "50225401000117106",
          "display" : "Etoposide (Rex) 100 mg/5 mL injection: concentrated, 1 x 5 mL vial"
        },
        {
          "extension" : [{
            "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/pharmac-is-primary-coding",
            "valueBoolean" : true
          }],
          "system" : "https://standards.digital.health.nz/ns/pharmac-subsidy-code",
          "code" : "2480913"
        }],
        "text" : "Etoposide (Rex) 100 mg/5 mL injection: concentrated, 1 x 5 mL vial"
      },
      "status" : "active",
      "form" : {
        "text" : "Inj 20 mg per ml, 5 ml vial"
      },
      "ingredient" : [{
        "itemCodeableConcept" : {
          "text" : "Etoposide"
        },
        "isActive" : true
      }]
    },
    "search" : {
      "mode" : "match"
    }
  },
  {
    "fullUrl" : "https://fhir-ig.digital.health.nz/pharmac-schedules/ChargeItemDefinition/ChargeItemDefinition-50225401000117106-Community-Case-1",
    "resource" : {
      "resourceType" : "ChargeItemDefinition",
      "id" : "ChargeItemDefinition-50225401000117106-Community-Case-1",
      "meta" : {
        "profile" : ["https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/pharmac-charge-item-definition-funding-rules"]
      },
      "extension" : [{
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/pricing-effective-date",
        "valueDate" : "2026-04-24"
      },
      {
        "extension" : [{
          "url" : "type",
          "valueCode" : "community"
        },
        {
          "extension" : [{
            "url" : "type",
            "valueCode" : "CaseSequence"
          },
          {
            "url" : "value",
            "valueInteger" : 1
          }],
          "url" : "rule"
        },
        {
          "extension" : [{
            "url" : "type",
            "valueCode" : "FundingMechanism"
          },
          {
            "url" : "attribute",
            "valueCode" : "Prescription"
          }],
          "url" : "rule"
        }],
        "url" : "http://schedule.pharmac.govt.nz/fhir/StructureDefinition/funding-rule"
      },
      {
        "extension" : [{
          "url" : "subsidyType",
          "valueCode" : "subsidy"
        },
        {
          "url" : "subsidyStatus",
          "valueCode" : "full"
        },
        {
          "url" : "amount",
          "valueMoney" : {
            "value" : 7.9,
            "currency" : "NZD"
          }
        },
        {
          "url" : "display",
          "valueString" : "Subsidy"
        }],
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/funding-subsidy-amount"
      },
      {
        "extension" : [{
          "url" : "costBrandSource",
          "valueBoolean" : false
        },
        {
          "url" : "wastageClaimable",
          "valueBoolean" : false
        },
        {
          "url" : "contractType",
          "valueString" : "n/a"
        },
        {
          "url" : "dvLimitPercent",
          "valueDecimal" : 0
        },
        {
          "url" : "brandSwitchFee",
          "valueBoolean" : false
        },
        {
          "url" : "statim",
          "valueString" : "n/a"
        },
        {
          "url" : "inCombination",
          "valueCode" : "no"
        },
        {
          "url" : "section29",
          "valueBoolean" : false
        },
        {
          "url" : "coPaymentMin",
          "valueCode" : "na"
        },
        {
          "url" : "coPaymentMax",
          "valueCode" : "no"
        },
        {
          "url" : "productMultiple",
          "valueBoolean" : false
        },
        {
          "url" : "productMultiplier",
          "valueInteger" : 0
        },
        {
          "url" : "originalPack",
          "valueBoolean" : false
        },
        {
          "url" : "safetyListMedicine",
          "valueBoolean" : false
        }],
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/schedule-funding-attributes"
      },
      {
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/authorization-schema",
        "valueBase64Binary" : "ewogICIkc2NoZW1hIjogImh0dHA6Ly9qc29uLXNjaGVtYS5vcmcvZHJhZnQtMDcvc2NoZW1hIyIsCiAgInRpdGxlIjogIkNvbmRpdGlvbnMtNTAyMjU0MDEwMDAxMTcxMDYtQ2FzZS0xIiwKICAidHlwZSI6ICJvYmplY3QiLAogICJwcm9wZXJ0aWVzIjogewogICAgInByb3ZpZGVyIjogewogICAgICAidGl0bGUiOiAiUHJvdmlkZXIgSW5mb3JtYXRpb24iLAogICAgICAidHlwZSI6ICJib29sZWFuIiwKICAgICAgImRlc2NyaXB0aW9uIjogIkF1dGhvcmlzZWQgcHJlc2NyaWJlciIKICAgIH0sCiAgICAic3BlY2lhbGlzdCI6IHsKICAgICAgInRpdGxlIjogIlNwZWNpYWxpc3QiLAogICAgICAidHlwZSI6ICJib29sZWFuIiwKICAgICAgImRlc2NyaXB0aW9uIjogIlNwZWNpYWxpc3QgcmVjb21tZW5kYXRpb24iCiAgICB9CiAgfSwKICAicmVxdWlyZWQiOiBbCiAgICAicHJvdmlkZXIiLAogICAgInNwZWNpYWxpc3QiCiAgXQp9Cg=="
      }],
      "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/ChargeItemDefinition/ChargeItemDefinition-50225401000117106-Community-Case-1",
      "version" : "1.0.1",
      "status" : "active",
      "date" : "2026-04-24T00:58:18+00:00",
      "publisher" : "Pharmac",
      "contact" : [{
        "name" : "Pharmac",
        "telecom" : [{
          "system" : "url",
          "value" : "https://www.pharmac.govt.nz/about/contact"
        }]
      },
      {
        "name" : "Pharmac",
        "telecom" : [{
          "system" : "email",
          "value" : "enquiry@pharmac.govt.nz",
          "use" : "work"
        }]
      }],
      "description" : "Rules for Etoposide (Rex) 100 mg/5 mL injection: concentrated, 1 x 5 mL vial. community Prescription.",
      "instance" : [{
        "reference" : "Medication/50225401000117106",
        "display" : "Etoposide (Rex) 100 mg/5 mL injection: concentrated, 1 x 5 mL vial"
      }],
      "applicability" : [{
        "description" : "Case 1 - Community - Prescription - Subsidy"
      }]
    },
    "search" : {
      "mode" : "include"
    }
  },
  {
    "fullUrl" : "https://fhir-ig.digital.health.nz/pharmac-schedules/ChargeItemDefinition/ChargeItemDefinition-50225401000117106-Community-Case-2",
    "resource" : {
      "resourceType" : "ChargeItemDefinition",
      "id" : "ChargeItemDefinition-50225401000117106-Community-Case-2",
      "meta" : {
        "profile" : ["https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/pharmac-charge-item-definition-funding-rules"]
      },
      "extension" : [{
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/pricing-effective-date",
        "valueDate" : "2026-04-24"
      },
      {
        "extension" : [{
          "url" : "type",
          "valueCode" : "community"
        },
        {
          "extension" : [{
            "url" : "type",
            "valueCode" : "CaseSequence"
          },
          {
            "url" : "value",
            "valueInteger" : 1
          }],
          "url" : "rule"
        },
        {
          "extension" : [{
            "url" : "type",
            "valueCode" : "FundingMechanism"
          },
          {
            "url" : "attribute",
            "valueCode" : "BSO"
          }],
          "url" : "rule"
        }],
        "url" : "http://schedule.pharmac.govt.nz/fhir/StructureDefinition/funding-rule"
      },
      {
        "extension" : [{
          "url" : "subsidyType",
          "valueCode" : "subsidy"
        },
        {
          "url" : "subsidyStatus",
          "valueCode" : "full"
        },
        {
          "url" : "amount",
          "valueMoney" : {
            "value" : 7.9,
            "currency" : "NZD"
          }
        },
        {
          "url" : "display",
          "valueString" : "Subsidy"
        }],
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/funding-subsidy-amount"
      },
      {
        "extension" : [{
          "url" : "costBrandSource",
          "valueBoolean" : false
        },
        {
          "url" : "wastageClaimable",
          "valueBoolean" : false
        },
        {
          "url" : "contractType",
          "valueString" : "n/a"
        },
        {
          "url" : "dvLimitPercent",
          "valueDecimal" : 0
        },
        {
          "url" : "brandSwitchFee",
          "valueBoolean" : false
        },
        {
          "url" : "statim",
          "valueString" : "n/a"
        },
        {
          "url" : "inCombination",
          "valueCode" : "no"
        },
        {
          "url" : "section29",
          "valueBoolean" : false
        },
        {
          "url" : "coPaymentMin",
          "valueCode" : "na"
        },
        {
          "url" : "coPaymentMax",
          "valueCode" : "no"
        },
        {
          "url" : "productMultiple",
          "valueBoolean" : false
        },
        {
          "url" : "productMultiplier",
          "valueInteger" : 0
        },
        {
          "url" : "originalPack",
          "valueBoolean" : false
        },
        {
          "url" : "safetyListMedicine",
          "valueBoolean" : false
        }],
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/schedule-funding-attributes"
      },
      {
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/authorization-schema",
        "valueBase64Binary" : "ewogICIkc2NoZW1hIjogImh0dHA6Ly9qc29uLXNjaGVtYS5vcmcvZHJhZnQtMDcvc2NoZW1hIyIsCiAgInRpdGxlIjogIkNvbmRpdGlvbnMtNTAyMjU0MDEwMDAxMTcxMDYtQ2FzZS0yIiwKICAidHlwZSI6ICJvYmplY3QiLAogICJwcm9wZXJ0aWVzIjogewogICAgInByb3ZpZGVyIjogewogICAgICAidGl0bGUiOiAiUHJvdmlkZXIgSW5mb3JtYXRpb24iLAogICAgICAidHlwZSI6ICJib29sZWFuIiwKICAgICAgImRlc2NyaXB0aW9uIjogIkhvc3BpdGFsIGNhcmUgb3BlcmF0b3IiCiAgICB9LAogICAgInNwZWNpYWxpc3QiOiB7CiAgICAgICJ0aXRsZSI6ICJTcGVjaWFsaXN0IiwKICAgICAgInR5cGUiOiAiYm9vbGVhbiIsCiAgICAgICJkZXNjcmlwdGlvbiI6ICJTcGVjaWFsaXN0IHJlY29tbWVuZGF0aW9uIgogICAgfQogIH0sCiAgInJlcXVpcmVkIjogWwogICAgInByb3ZpZGVyIiwKICAgICJzcGVjaWFsaXN0IgogIF0KfQo="
      }],
      "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/ChargeItemDefinition/ChargeItemDefinition-50225401000117106-Community-Case-2",
      "version" : "1.0.1",
      "status" : "active",
      "date" : "2026-04-24T00:58:18+00:00",
      "publisher" : "Pharmac",
      "contact" : [{
        "name" : "Pharmac",
        "telecom" : [{
          "system" : "url",
          "value" : "https://www.pharmac.govt.nz/about/contact"
        }]
      },
      {
        "name" : "Pharmac",
        "telecom" : [{
          "system" : "email",
          "value" : "enquiry@pharmac.govt.nz",
          "use" : "work"
        }]
      }],
      "description" : "Rules for Etoposide (Rex) 100 mg/5 mL injection: concentrated, 1 x 5 mL vial. community BSO.",
      "instance" : [{
        "reference" : "Medication/50225401000117106",
        "display" : "Etoposide (Rex) 100 mg/5 mL injection: concentrated, 1 x 5 mL vial"
      }],
      "applicability" : [{
        "description" : "Case 2 - Community - BSO - Subsidy"
      }]
    },
    "search" : {
      "mode" : "include"
    }
  },
  {
    "fullUrl" : "https://fhir-ig.digital.health.nz/pharmac-schedules/ChargeItemDefinition/ChargeItemDefinition-50225401000117106-Community-Case-3",
    "resource" : {
      "resourceType" : "ChargeItemDefinition",
      "id" : "ChargeItemDefinition-50225401000117106-Community-Case-3",
      "meta" : {
        "profile" : ["https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/pharmac-charge-item-definition-funding-rules"]
      },
      "extension" : [{
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/pricing-effective-date",
        "valueDate" : "2026-04-24"
      },
      {
        "extension" : [{
          "url" : "type",
          "valueCode" : "community"
        },
        {
          "extension" : [{
            "url" : "type",
            "valueCode" : "CaseSequence"
          },
          {
            "url" : "value",
            "valueInteger" : 1
          }],
          "url" : "rule"
        },
        {
          "extension" : [{
            "url" : "type",
            "valueCode" : "FundingMechanism"
          },
          {
            "url" : "attribute",
            "valueCode" : "RuralPSO"
          }],
          "url" : "rule"
        }],
        "url" : "http://schedule.pharmac.govt.nz/fhir/StructureDefinition/funding-rule"
      },
      {
        "extension" : [{
          "url" : "subsidyType",
          "valueCode" : "subsidy"
        },
        {
          "url" : "subsidyStatus",
          "valueCode" : "full"
        },
        {
          "url" : "amount",
          "valueMoney" : {
            "value" : 7.9,
            "currency" : "NZD"
          }
        },
        {
          "url" : "display",
          "valueString" : "Subsidy"
        }],
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/funding-subsidy-amount"
      },
      {
        "extension" : [{
          "url" : "costBrandSource",
          "valueBoolean" : false
        },
        {
          "url" : "wastageClaimable",
          "valueBoolean" : false
        },
        {
          "url" : "contractType",
          "valueString" : "n/a"
        },
        {
          "url" : "dvLimitPercent",
          "valueDecimal" : 0
        },
        {
          "url" : "brandSwitchFee",
          "valueBoolean" : false
        },
        {
          "url" : "statim",
          "valueString" : "n/a"
        },
        {
          "url" : "inCombination",
          "valueCode" : "no"
        },
        {
          "url" : "section29",
          "valueBoolean" : false
        },
        {
          "url" : "coPaymentMin",
          "valueCode" : "na"
        },
        {
          "url" : "coPaymentMax",
          "valueCode" : "no"
        },
        {
          "url" : "productMultiple",
          "valueBoolean" : false
        },
        {
          "url" : "productMultiplier",
          "valueInteger" : 0
        },
        {
          "url" : "originalPack",
          "valueBoolean" : false
        },
        {
          "url" : "safetyListMedicine",
          "valueBoolean" : false
        }],
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/schedule-funding-attributes"
      },
      {
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/authorization-schema",
        "valueBase64Binary" : "ewogICIkc2NoZW1hIjogImh0dHA6Ly9qc29uLXNjaGVtYS5vcmcvZHJhZnQtMDcvc2NoZW1hIyIsCiAgInRpdGxlIjogIkNvbmRpdGlvbnMtNTAyMjU0MDEwMDAxMTcxMDYtQ2FzZS0zIiwKICAidHlwZSI6ICJvYmplY3QiLAogICJwcm9wZXJ0aWVzIjogewogICAgInByb3ZpZGVyIjogewogICAgICAidGl0bGUiOiAiUHJvdmlkZXIgSW5mb3JtYXRpb24iLAogICAgICAidHlwZSI6ICJib29sZWFuIiwKICAgICAgImRlc2NyaXB0aW9uIjogIkhvc3BpdGFsIGNhcmUgb3BlcmF0b3IiCiAgICB9LAogICAgInNwZWNpYWxpc3QiOiB7CiAgICAgICJ0aXRsZSI6ICJTcGVjaWFsaXN0IiwKICAgICAgInR5cGUiOiAiYm9vbGVhbiIsCiAgICAgICJkZXNjcmlwdGlvbiI6ICJTcGVjaWFsaXN0IHJlY29tbWVuZGF0aW9uIgogICAgfQogIH0sCiAgInJlcXVpcmVkIjogWwogICAgInByb3ZpZGVyIiwKICAgICJzcGVjaWFsaXN0IgogIF0KfQo="
      }],
      "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/ChargeItemDefinition/ChargeItemDefinition-50225401000117106-Community-Case-3",
      "version" : "1.0.1",
      "status" : "active",
      "date" : "2026-04-24T00:58:18+00:00",
      "publisher" : "Pharmac",
      "contact" : [{
        "name" : "Pharmac",
        "telecom" : [{
          "system" : "url",
          "value" : "https://www.pharmac.govt.nz/about/contact"
        }]
      },
      {
        "name" : "Pharmac",
        "telecom" : [{
          "system" : "email",
          "value" : "enquiry@pharmac.govt.nz",
          "use" : "work"
        }]
      }],
      "description" : "Rules for Etoposide (Rex) 100 mg/5 mL injection: concentrated, 1 x 5 mL vial. community Rural PSO.",
      "instance" : [{
        "reference" : "Medication/50225401000117106",
        "display" : "Etoposide (Rex) 100 mg/5 mL injection: concentrated, 1 x 5 mL vial"
      }],
      "applicability" : [{
        "description" : "Case 3 - Community - Rural PSO - Subsidy"
      }]
    },
    "search" : {
      "mode" : "include"
    }
  },
  {
    "fullUrl" : "https://fhir-ig.digital.health.nz/pharmac-schedules/ChargeItemDefinition/ChargeItemDefinition-50225401000117106-Hospital-Case-7",
    "resource" : {
      "resourceType" : "ChargeItemDefinition",
      "id" : "ChargeItemDefinition-50225401000117106-Hospital-Case-7",
      "meta" : {
        "profile" : ["https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/pharmac-charge-item-definition-funding-rules"]
      },
      "extension" : [{
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/pricing-effective-date",
        "valueDate" : "2026-04-24"
      },
      {
        "extension" : [{
          "url" : "type",
          "valueCode" : "hospital"
        },
        {
          "extension" : [{
            "url" : "type",
            "valueCode" : "CaseSequence"
          },
          {
            "url" : "value",
            "valueInteger" : 1
          }],
          "url" : "rule"
        },
        {
          "extension" : [{
            "url" : "type",
            "valueCode" : "FundingMechanism"
          },
          {
            "url" : "attribute",
            "valueCode" : "Prescription"
          }],
          "url" : "rule"
        }],
        "url" : "http://schedule.pharmac.govt.nz/fhir/StructureDefinition/funding-rule"
      },
      {
        "extension" : [{
          "url" : "subsidyType",
          "valueCode" : "subsidy"
        },
        {
          "url" : "subsidyStatus",
          "valueCode" : "full"
        },
        {
          "url" : "amount",
          "valueMoney" : {
            "value" : 7.9,
            "currency" : "NZD"
          }
        },
        {
          "url" : "display",
          "valueString" : "Subsidy"
        }],
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/funding-subsidy-amount"
      },
      {
        "extension" : [{
          "url" : "costBrandSource",
          "valueBoolean" : false
        },
        {
          "url" : "wastageClaimable",
          "valueBoolean" : false
        },
        {
          "url" : "contractType",
          "valueString" : "n/a"
        },
        {
          "url" : "dvLimitPercent",
          "valueDecimal" : 0
        },
        {
          "url" : "brandSwitchFee",
          "valueBoolean" : false
        },
        {
          "url" : "statim",
          "valueString" : "n/a"
        },
        {
          "url" : "inCombination",
          "valueCode" : "no"
        },
        {
          "url" : "section29",
          "valueBoolean" : false
        },
        {
          "url" : "coPaymentMin",
          "valueCode" : "na"
        },
        {
          "url" : "coPaymentMax",
          "valueCode" : "no"
        },
        {
          "url" : "productMultiple",
          "valueBoolean" : false
        },
        {
          "url" : "productMultiplier",
          "valueInteger" : 0
        },
        {
          "url" : "originalPack",
          "valueBoolean" : false
        },
        {
          "url" : "safetyListMedicine",
          "valueBoolean" : false
        }],
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/schedule-funding-attributes"
      },
      {
        "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/authorization-schema",
        "valueBase64Binary" : "e30K"
      }],
      "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/ChargeItemDefinition/ChargeItemDefinition-50225401000117106-Hospital-Case-7",
      "version" : "1.0.1",
      "status" : "active",
      "date" : "2026-04-24T00:58:18+00:00",
      "publisher" : "Pharmac",
      "contact" : [{
        "name" : "Pharmac",
        "telecom" : [{
          "system" : "url",
          "value" : "https://www.pharmac.govt.nz/about/contact"
        }]
      },
      {
        "name" : "Pharmac",
        "telecom" : [{
          "system" : "email",
          "value" : "enquiry@pharmac.govt.nz",
          "use" : "work"
        }]
      }],
      "description" : "Rules for Etoposide (Rex) 100 mg/5 mL injection: concentrated, 1 x 5 mL vial. hospital Prescription.",
      "instance" : [{
        "reference" : "Medication/50225401000117106",
        "display" : "Etoposide (Rex) 100 mg/5 mL injection: concentrated, 1 x 5 mL vial"
      }],
      "applicability" : [{
        "description" : "Case 7 - Hospital - Prescription - Subsidy"
      }]
    },
    "search" : {
      "mode" : "include"
    }
  }]
}

```
