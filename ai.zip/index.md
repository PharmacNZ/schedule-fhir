# Home - Pharmac Schedules FHIR API v0.0.1

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://fhir-ig.digital.health.nz/pharmac-schedules/ImplementationGuide/pharmac.fhir.pharmac-schedules | *Version*:0.0.1 |
| Draft as of 2026-03-27 | *Computable Name*:pharmacschedules |

# Pharmac Schedules FHIR API

The Pharmac Schedules FHIR API provides access to schedule data for funded medicines and devices. This Fast Healthcare Interoperable Resources (FHIR) API publishes Schedule data using standard FHIR resources to support integration and reuse. API Consumers can query the Pharmac Schedules API to retrieve information about funded items and related details.

# Who can use this API

This API is intended for approved consumers integrating Pharmac schedule information into their systems.

# Onboarding and Implementation

Contact the Pharmac team to request access and onboarding details.

