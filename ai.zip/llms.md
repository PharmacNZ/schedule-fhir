# pharmac.fhir.pharmac-schedules#1.0.1: Pharmac Schedules FHIR API

## Pages

* [Pharmac Medicine & Medical Device Schedule](index.md)
* [JSON Schema for Special Authorities](sa-json-schema-guide.md)
* [JSON Schema for Funding Rules](fr-json-schema-guide.md)
* [Artifacts Summary](artifacts.md)
* [Examples](examples.md)
* [Resource Relationships](relationships.md)
* [XML to FHIR Mapping](fhir-ig-to-xml.md)
* [Terminology](terminology.md)
* [Version History](version-history.md)
* [API](api.md)
* [Data Models](datamodel.md)
* [Use Cases](use-cases.md)

## Resources

### ValueSets

* [Medication Form Codes](ValueSet-medication-form-codes.md)
* [PHARMAC Medication Code ValueSet](ValueSet-pharmac-medication-code.md)
* [SNOMED CT Device Types](ValueSet-snomed-ct-device-types.md)

### Resource Profiles

* [PHARMAC Charge Item Definition - Funding Rules](StructureDefinition-pharmac-charge-item-definition-funding-rules.md)
* [PHARMAC Charge Item Definition - Pricing](StructureDefinition-pharmac-charge-item-definition-pricing.md)
* [PHARMAC Charge Item Definition - Special Authority](StructureDefinition-pharmac-charge-item-definition-special-authority.md)
* [PHARMAC Charge Item Definition](StructureDefinition-pharmac-charge-item-definition.md)
* [PHARMAC Medication](StructureDefinition-pharmac-medication.md)

### Extensions

* [Authorization Case Count](StructureDefinition-authorization-case-count.md)
* [Authorization Form](StructureDefinition-authorization-form.md)
* [Authorization Schema](StructureDefinition-authorization-schema.md)
* [Authorization Title](StructureDefinition-authorization-title.md)
* [Brand Switch Fee](StructureDefinition-brand-switch-fee.md)
* [Contract Type](StructureDefinition-contract-type.md)
* [Cost Brand Source](StructureDefinition-cost-brand-source.md)
* [Device Definition Reference](StructureDefinition-device-definition-reference.md)
* [Daily Volume Limit Percent](StructureDefinition-dv-limit-percent.md)
* [Funding Rule](StructureDefinition-funding-rule.md)
* [In-Combination](StructureDefinition-in-combination.md)
* [Medication ATC Category 1](StructureDefinition-medication-atc-category-1.md)
* [Medication ATC Category 2](StructureDefinition-medication-atc-category-2.md)
* [Medication ATC Category 3](StructureDefinition-medication-atc-category-3.md)
* [Medication Brand Name](StructureDefinition-medication-brand-name.md)
* [Medication In Combination](StructureDefinition-medication-in-combination.md)
* [Medication Legal Classification](StructureDefinition-medication-legal-classification.md)
* [Medication Original Pack](StructureDefinition-medication-original-pack.md)
* [Medication Package Size](StructureDefinition-medication-package-size.md)
* [Medication Product Created Date](StructureDefinition-medication-product-created-date.md)
* [Medication Product Multiple](StructureDefinition-medication-product-multiple.md)
* [Medication Product Multiplier](StructureDefinition-medication-product-multiplier.md)
* [Medication Rank](StructureDefinition-medication-rank.md)
* [Medication Safety List Medicine](StructureDefinition-medication-safety-list-medicine.md)
* [Medication Statim](StructureDefinition-medication-statim.md)
* [Medication Strength](StructureDefinition-medication-strength.md)
* [Medication Unit of Measure](StructureDefinition-medication-unit-of-measure.md)
* [Pricing Co-Payment Max](StructureDefinition-pricing-copayment-max.md)
* [Pricing Effective Date](StructureDefinition-pricing-effective-date.md)
* [Pricing Expiry Date](StructureDefinition-pricing-expiry-date.md)
* [Pricing Not Combined](StructureDefinition-pricing-not-combined.md)
* [Pricing Section 29](StructureDefinition-pricing-section-29.md)
* [Statim (Urgent Dispensing)](StructureDefinition-statim.md)
* [Wastage Claimable](StructureDefinition-wastage-claimable.md)

### CapabilityStatements

* [Pharmac Schedules Capability Statement](CapabilityStatement-PharmacSchedulesCapabilityStatement.md)

### ImplementationGuides

* [Pharmac Schedules FHIR API](index.md)

### SearchParameters

* [ChargeItemDefinitionCode](SearchParameter-ChargeItemDefinitionCodeSearchParam.md)
* [device-definition-reference](SearchParameter-ChargeItemDefinitionDeviceReferenceSearchParam.md)
* [ChargeItemDefinitionInstance](SearchParameter-ChargeItemDefinitionInstanceSearchParam.md)
* [PricingEffectiveDate](SearchParameter-ChargeItemDefinitionPricingEffectiveDateSearchParam.md)
* [ChargeItemDefinitionSACode](SearchParameter-ChargeItemDefinitionSACodeSearchParam.md)
* [brand](SearchParameter-MedicationBrandNameSearchParam.md)
* [medication-category](SearchParameter-MedicationCategorySearchParam.md)
* [MedicationName](SearchParameter-MedicationNameSearchParam.md)

### Examples

* [SearchSet-Bundle-All-Medications (Bundle)](Bundle-SearchSet-Bundle-All-Medications.md)
* [SearchSet-Bundle-All-Special-Authorities (Bundle)](Bundle-SearchSet-Bundle-All-Special-Authorities.md)
* [SearchSet-Bundle-Clexane-Pricing (Bundle)](Bundle-SearchSet-Bundle-Clexane-Pricing.md)
* [ChargeItemDefinition-Clexane-100mg-1ml-Syringe-Case-1 (ChargeItemDefinition)](ChargeItemDefinition-ChargeItemDefinition-Clexane-100mg-1ml-Syringe-Case-1.md)
* [ChargeItemDefinition-Clexane-100mg-1ml-Syringe-Case-2 (ChargeItemDefinition)](ChargeItemDefinition-ChargeItemDefinition-Clexane-100mg-1ml-Syringe-Case-2.md)
* [ChargeItemDefinition-Clexane-100mg-1ml-Syringe-Case-3 (ChargeItemDefinition)](ChargeItemDefinition-ChargeItemDefinition-Clexane-100mg-1ml-Syringe-Case-3.md)
* [Clexane - Pricing (ChargeItemDefinition)](ChargeItemDefinition-ChargeItemDefinition-Clexane-Pricing.md)
* [ChargeItemDefinition-SA9999-Authorization (ChargeItemDefinition)](ChargeItemDefinition-ChargeItemDefinition-SA9999-Authorization.md)
* [Medication-Clexane-100mg-1ml-Syringe (Medication)](Medication-Medication-Clexane-100mg-1ml-Syringe.md)
* [Medication-Fortisip-Multi-Fibre-Chocolate (Medication)](Medication-Medication-Fortisip-Multi-Fibre-Chocolate.md)
* [Medication-Nutrison-800-Complete-Multi-Fibre (Medication)](Medication-Medication-Nutrison-800-Complete-Multi-Fibre.md)
* [APIError-Unauthorised (OperationOutcome)](OperationOutcome-APIError-Unauthorised.md)
