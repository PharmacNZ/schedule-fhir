# pharmac.fhir.pharmac-schedules#0.0.1: Pharmac Schedules FHIR API

## Pages

* [Home](index.md)
* [Examples](examples.md)
* [Use Cases](use-cases.md)
* [Terminology](terminology.md)
* [Artifacts Summary](artifacts.md)
* [Api](api.md)
* [Datamodel](datamodel.md)
* [Relationships](relationships.md)

## Resources

### ValueSets

* [Medication Form Codes](ValueSet-medication-form-codes.md)
* [PHARMAC Medication Code ValueSet](ValueSet-pharmac-medication-code.md)
* [SNOMED CT Device Types](ValueSet-snomed-ct-device-types.md)

### Resource Profiles

* [PHARMAC Charge Item Definition](StructureDefinition-pharmac-charge-item-definition.md)
* [PHARMAC Medication](StructureDefinition-pharmac-medication.md)

### Extensions

* [Authorization Case Count](StructureDefinition-authorization-case-count.md)
* [Authorization Form](StructureDefinition-authorization-form.md)
* [Authorization Title](StructureDefinition-authorization-title.md)
* [Brand Switch Fee](StructureDefinition-brand-switch-fee.md)
* [Contract Type](StructureDefinition-contract-type.md)
* [Cost Brand Source](StructureDefinition-cost-brand-source.md)
* [Device Definition Reference](StructureDefinition-device-definition-reference.md)
* [Daily Volume Limit Percent](StructureDefinition-dv-limit-percent.md)
* [Funding Rule](StructureDefinition-funding-rule.md)
* [In-Combination](StructureDefinition-in-combination.md)
* [Medication ATC Category 1](StructureDefinition-medication-atc-category-1.md)
* [Medication ATC Category 2](StructureDefinition-medication-atc-category-2.md)
* [Medication ATC Category 3](StructureDefinition-medication-atc-category-3.md)
* [Medication Brand Name](StructureDefinition-medication-brand-name.md)
* [Medication In Combination](StructureDefinition-medication-in-combination.md)
* [Medication Original Pack](StructureDefinition-medication-original-pack.md)
* [Medication Package Size](StructureDefinition-medication-package-size.md)
* [Medication Product Multiple](StructureDefinition-medication-product-multiple.md)
* [Medication Product Multiplier](StructureDefinition-medication-product-multiplier.md)
* [Medication Rank](StructureDefinition-medication-rank.md)
* [Medication Safety List Medicine](StructureDefinition-medication-safety-list-medicine.md)
* [Medication Statim](StructureDefinition-medication-statim.md)
* [Medication Unit of Measure](StructureDefinition-medication-unit-of-measure.md)
* [Pricing Effective Date](StructureDefinition-pricing-effective-date.md)
* [Pricing Expiry Date](StructureDefinition-pricing-expiry-date.md)
* [Statim (Urgent Dispensing)](StructureDefinition-statim.md)
* [Wastage Claimable](StructureDefinition-wastage-claimable.md)

### CapabilityStatements

* [Pharmac Schedules Capability Statement](CapabilityStatement-PharmacSchedulesCapabilityStatement.md)

### ImplementationGuides

* [Pharmac Schedules FHIR API](index.md)

### SearchParameters

* [ChargeItemDefinitionCode](SearchParameter-ChargeItemDefinitionCodeSearchParam.md)
* [brand](SearchParameter-MedicationBrandNameSearchParam.md)
* [MedicationName](SearchParameter-MedicationNameSearchParam.md)

### Examples

* [SearchSet-Bundle-Leuprorelin-Pricing (Bundle)](Bundle-SearchSet-Bundle-Leuprorelin-Pricing.md)
* [SearchSet-Bundle-Medication (Bundle)](Bundle-SearchSet-Bundle-Medication.md)
* [SearchSet-Bundle-Ricovir-Pricing (Bundle)](Bundle-SearchSet-Bundle-Ricovir-Pricing.md)
* [SearchSet-Bundle-SA2139-Authorization (Bundle)](Bundle-SearchSet-Bundle-SA2139-Authorization.md)
* [ChargeItemDefinition-Community-Pharmacy-Rural-PSO-Sequence-1 (ChargeItemDefinition)](ChargeItemDefinition-ChargeItemDefinition-Community-Pharmacy-Rural-PSO-Sequence-1.md)
* [ChargeItemDefinition-Community-Pharmacy-BSO-Sequence-1 (ChargeItemDefinition)](ChargeItemDefinition-ChargeItemDefinition-Community-Pharmacy-BSO-Sequence-1.md)
* [ChargeItemDefinition-Community-Pharmacy-Sequence-1 (ChargeItemDefinition)](ChargeItemDefinition-ChargeItemDefinition-Community-Pharmacy-Sequence-1.md)
* [ChargeItemDefinition-Community-Pharmacy-Sequence-2 (ChargeItemDefinition)](ChargeItemDefinition-ChargeItemDefinition-Community-Pharmacy-Sequence-2.md)
* [Lucrin Depot 1-month - Pricing (ChargeItemDefinition)](ChargeItemDefinition-ChargeItemDefinition-Lucrin-Depot-1-Month-Pricing.md)
* [Ricovir - Pricing (ChargeItemDefinition)](ChargeItemDefinition-ChargeItemDefinition-Ricovir-Pricing.md)
* [ChargeItemDefinition-SA2139-Authorization (ChargeItemDefinition)](ChargeItemDefinition-ChargeItemDefinition-SA2139-Authorization.md)
* [ChargeItemDefinition-SA2520-Authorization (ChargeItemDefinition)](ChargeItemDefinition-ChargeItemDefinition-SA2520-Authorization.md)
* [ChargeItemDefinition-Tenofovir-Case-Sequence-1 (ChargeItemDefinition)](ChargeItemDefinition-ChargeItemDefinition-Tenofovir-Case-Sequence-1.md)
* [ChargeItemDefinition-Tenofovir-Case-Sequence-2 (ChargeItemDefinition)](ChargeItemDefinition-ChargeItemDefinition-Tenofovir-Case-Sequence-2.md)
* [Medication-Lucrin-Depot-1-Month (Medication)](Medication-Medication-Lucrin-Depot-1-Month.md)
* [Medication-Ricovir-Tenofovir (Medication)](Medication-Medication-Ricovir-Tenofovir.md)
* [Medication-Viramune-Suspension (Medication)](Medication-Medication-Viramune-Suspension.md)
* [APIError-Unauthorised (OperationOutcome)](OperationOutcome-APIError-Unauthorised.md)
