# Medication-Ricovir-Tenofovir - Pharmac Schedules FHIR API v0.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Medication-Ricovir-Tenofovir**

## Example Medication: Medication-Ricovir-Tenofovir



## Resource Content

```json
{
  "resourceType" : "Medication",
  "id" : "Medication-Ricovir-Tenofovir",
  "meta" : {
    "profile" : ["https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/pharmac-medication"]
  },
  "extension" : [{
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-brand-name",
    "valueString" : "Ricovir"
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-package-size",
    "valueString" : "30"
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-unit-of-measure",
    "valueString" : "tab"
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-rank",
    "valueInteger" : 1
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-atc-category-1",
    "valueString" : "Infections - Agents for Systemic Use"
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-atc-category-2",
    "valueString" : "Antivirals"
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-atc-category-3",
    "valueString" : "Hepatitis B Treatment"
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-product-multiple",
    "valueBoolean" : false
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-product-multiplier",
    "valueInteger" : 0
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-original-pack",
    "valueBoolean" : false
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/medication-safety-list-medicine",
    "valueBoolean" : false
  }],
  "identifier" : [{
    "system" : "http://schedule.pharmac.govt.nz/ids/brand",
    "value" : "B16190538672526"
  },
  {
    "system" : "http://schedule.pharmac.govt.nz/ids/pack",
    "value" : "P2703122"
  },
  {
    "system" : "http://schedule.pharmac.govt.nz/ids/chemical",
    "value" : "C1619053867"
  },
  {
    "system" : "http://schedule.pharmac.govt.nz/ids/formulation",
    "value" : "F161905386725"
  },
  {
    "system" : "http://schedule.pharmac.govt.nz/ids/pharmacode",
    "value" : "2703122"
  }],
  "code" : {
    "coding" : [{
      "system" : "http://nzmt.org.nz",
      "code" : "50348251000117105",
      "display" : "Tenofovir disoproxil 300 tab, 30 tab"
    }],
    "text" : "Tenofovir disoproxil"
  },
  "status" : "active",
  "form" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "385055001",
      "display" : "Tablet"
    }],
    "text" : "Tab 245 mg (300 mg as a fumarate)"
  },
  "ingredient" : [{
    "itemCodeableConcept" : {
      "coding" : [{
        "system" : "http://nzmt.org.nz",
        "code" : "46616121000116103",
        "display" : "tenofovir disoproxil"
      }],
      "text" : "tenofovir disoproxil"
    },
    "isActive" : true
  }]
}

```
