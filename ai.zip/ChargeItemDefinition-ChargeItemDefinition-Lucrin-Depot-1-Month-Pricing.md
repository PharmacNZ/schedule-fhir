# Lucrin Depot 1-month - Pricing - Pharmac Schedules FHIR API v0.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Lucrin Depot 1-month - Pricing**

## Example ChargeItemDefinition: Lucrin Depot 1-month - Pricing

| |
| :--- |
| Active as of 2026-03-27 |



## Resource Content

```json
{
  "resourceType" : "ChargeItemDefinition",
  "id" : "ChargeItemDefinition-Lucrin-Depot-1-Month-Pricing",
  "meta" : {
    "profile" : ["https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/pharmac-charge-item-definition"]
  },
  "extension" : [{
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/pricing-effective-date",
    "valueDate" : "2025-12-01"
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/cost-brand-source",
    "valueBoolean" : false
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/wastage-claimable",
    "valueBoolean" : false
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/statim",
    "valueString" : "n/a"
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/in-combination",
    "valueString" : "n/a"
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/contract-type",
    "valueString" : "n/a"
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/dv-limit-percent",
    "valueDecimal" : 0
  },
  {
    "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/StructureDefinition/brand-switch-fee",
    "valueBoolean" : false
  }],
  "url" : "https://fhir-ig.digital.health.nz/pharmac-schedules/ChargeItemDefinition/ChargeItemDefinition-Lucrin-Depot-1-Month-Pricing",
  "version" : "0.0.1",
  "title" : "Lucrin Depot 1-month - Pricing",
  "status" : "active",
  "date" : "2026-03-27T00:29:47+00:00",
  "publisher" : "Pharmac",
  "contact" : [{
    "name" : "Pharmac",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.pharmac.govt.nz/about/contact"
    }]
  },
  {
    "name" : "Pharmac",
    "telecom" : [{
      "system" : "email",
      "value" : "enquiry@pharmac.govt.nz",
      "use" : "work"
    }]
  }],
  "description" : "Listed price, PHARMAC subsidy, and patient co-payment for Lucrin Depot 1-month (Leuprorelin 3.75 inj, 1 inj)",
  "instance" : [{
    "reference" : "Medication/Medication-Lucrin-Depot-1-Month"
  }],
  "applicability" : [{
    "description" : "Community (subsidized) pricing applicable with valid prescription"
  }],
  "propertyGroup" : [{
    "applicability" : [{
      "description" : "Community (subsidized) pricing"
    }],
    "priceComponent" : [{
      "type" : "base",
      "code" : {
        "text" : "Listed Price"
      },
      "amount" : {
        "value" : 221.6,
        "currency" : "NZD"
      }
    },
    {
      "type" : "discount",
      "code" : {
        "text" : "PHARMAC Subsidy"
      },
      "amount" : {
        "value" : 66.48,
        "currency" : "NZD"
      }
    },
    {
      "type" : "surcharge",
      "code" : {
        "text" : "Patient Surcharge"
      },
      "amount" : {
        "value" : 155.12,
        "currency" : "NZD"
      }
    },
    {
      "type" : "informational",
      "code" : {
        "text" : "Patient Co-Payment (with limit)"
      },
      "amount" : {
        "value" : 0,
        "currency" : "NZD"
      }
    }]
  },
  {
    "applicability" : [{
      "description" : "Alternative pricing structure"
    }],
    "priceComponent" : [{
      "type" : "base",
      "code" : {
        "text" : "Alternative Listed Price"
      },
      "amount" : {
        "value" : 221.6,
        "currency" : "NZD"
      }
    },
    {
      "type" : "discount",
      "code" : {
        "text" : "Alternative Subsidy/Reimbursement"
      },
      "amount" : {
        "value" : 221.6,
        "currency" : "NZD"
      }
    },
    {
      "type" : "informational",
      "code" : {
        "text" : "Alternative Patient Cost"
      },
      "amount" : {
        "value" : 0,
        "currency" : "NZD"
      }
    }]
  }]
}

```
